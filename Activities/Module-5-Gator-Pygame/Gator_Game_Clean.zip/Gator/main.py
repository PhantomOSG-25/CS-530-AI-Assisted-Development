import math
import random

import pygame


# Initialize Pygame modules before using the display or event system.
pygame.init()

# Create the game window and set its title.
window_width = 960
window_height = 640
screen = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption("Gator")

# The bright player colors stand out against the darker swamp background.
swamp_green = (42, 82, 56)
gator_green = (126, 207, 91)
dark_green = (35, 91, 58)
belly_green = (215, 211, 139)
eye_color = (255, 221, 74)
black = (22, 30, 22)
white = (245, 245, 230)
fish_blue = (67, 207, 222)
fish_outline = (20, 75, 112)
frog_orange = (255, 153, 61)
frog_outline = (126, 62, 40)
food_eye_white = (255, 250, 220)
turtle_shell = (150, 107, 56)
turtle_shell_light = (196, 151, 83)
turtle_skin = (119, 184, 91)
person_shirt = (235, 133, 72)
person_pants = (79, 132, 191)
person_skin = (230, 185, 142)
officer_uniform = (73, 110, 147)
officer_uniform_light = (112, 151, 180)
officer_hat = (42, 69, 91)
officer_badge = (237, 204, 93)

# The clock limits the loop to a steady, reasonable frame rate.
clock = pygame.time.Clock()
frames_per_second = 60
player_speed = 220
player_position = pygame.Vector2(window_width / 2, window_height / 2)
facing_direction = pygame.Vector2(1, 0)
score = 0
font = pygame.font.Font(None, 32)
baby_gator_scale = 0.65
# Keep each growth stage longer: Baby is 0-74, Juvenile is 75-149,
# and Adult starts at 150 points.
juvenile_score_threshold = 75
adult_score_threshold = 150
win_score = 250
growth_stages = (
    ("Baby", 0, baby_gator_scale),
    ("Juvenile", juvenile_score_threshold, 0.85),
    ("Adult", adult_score_threshold, 1.05),
)
food_items = []
person_items = []
officer_position: pygame.Vector2 | None = None
officer_collision_radius = 20
officer_speed = 48
officer_respawn_delay_ms = 1800
officer_respawn_at = 0
health = 3
maximum_health = 3
invulnerability_duration_ms = 1400
invulnerable_until = 0
game_over = False
game_won = False
bite_duration_ms = 180
bite_cooldown_ms = 500
bite_visible_until = 0
bite_cooldown_until = 0


def make_baby_gator(direction, scale):
    """Build the shape-drawn alligator and rotate/scale it for its growth stage."""
    # Drawing in a separate transparent surface keeps the body-part coordinates
    # simple; the completed image can then face whichever way the player moved.
    gator = pygame.Surface((180, 120), pygame.SRCALPHA)

    # A tapered tail and wide, rounded torso form a distinctly reptilian body.
    pygame.draw.polygon(
        gator,
        dark_green,
        [(10, 52), (49, 43), (62, 52), (62, 68), (49, 77), (10, 68), (2, 60)],
    )
    pygame.draw.polygon(
        gator,
        gator_green,
        [(10, 60), (49, 48), (59, 56), (59, 64), (49, 72), (10, 60)],
    )

    # The broad torso has a contrasting belly and raised back scales.
    pygame.draw.ellipse(gator, dark_green, (37, 28, 89, 64))
    pygame.draw.ellipse(gator, gator_green, (41, 31, 81, 58))
    pygame.draw.ellipse(gator, belly_green, (53, 49, 64, 31))
    for scale_x in (57, 71, 85, 99):
        pygame.draw.polygon(
            gator,
            dark_green,
            [(scale_x, 34), (scale_x + 6, 25), (scale_x + 12, 34)],
        )

    # Four short legs extend from the visible edges of the torso.
    leg_shapes = (
        ([(49, 42), (62, 34), (60, 15), (72, 12), (80, 38), (69, 49)], -1),
        ([(49, 78), (62, 86), (60, 105), (72, 108), (80, 82), (69, 71)], 1),
        ([(91, 39), (105, 34), (106, 16), (118, 16), (121, 43), (109, 51)], -1),
        ([(91, 81), (105, 86), (106, 104), (118, 104), (121, 77), (109, 69)], 1),
    )
    for leg_points, toe_direction in leg_shapes:
        pygame.draw.polygon(gator, dark_green, leg_points)
        pygame.draw.polygon(
            gator,
            gator_green,
            [(x + 2, y + toe_direction * 2) for x, y in leg_points],
        )
        toe_x, toe_y = leg_points[2]
        pygame.draw.line(
            gator,
            belly_green,
            (toe_x, toe_y),
            (toe_x - 5, toe_y + toe_direction * 5),
            2,
        )
        pygame.draw.line(
            gator,
            belly_green,
            (toe_x + 5, toe_y),
            (toe_x + 1, toe_y + toe_direction * 6),
            2,
        )

    # A raised, wide head narrows into the long, squared alligator snout.
    pygame.draw.ellipse(gator, dark_green, (96, 31, 43, 58))
    pygame.draw.ellipse(gator, gator_green, (100, 34, 38, 52))
    pygame.draw.polygon(
        gator,
        dark_green,
        [(122, 39), (158, 42), (171, 49), (171, 71), (158, 78), (122, 81)],
    )
    pygame.draw.polygon(
        gator,
        gator_green,
        [(124, 43), (157, 46), (167, 51), (167, 68), (157, 74), (124, 77)],
    )
    pygame.draw.polygon(
        gator,
        belly_green,
        [(127, 62), (164, 62), (163, 69), (156, 73), (127, 73)],
    )

    # Two visible eyes, nostrils, and a jaw line give the head reptile features.
    for eye_y in (43, 77):
        pygame.draw.circle(gator, dark_green, (126, eye_y), 9)
        pygame.draw.circle(gator, eye_color, (128, eye_y), 6)
        pygame.draw.circle(gator, black, (130, eye_y), 3)
    pygame.draw.circle(gator, dark_green, (160, 52), 2)
    pygame.draw.circle(gator, dark_green, (160, 66), 2)
    pygame.draw.line(gator, dark_green, (137, 60), (166, 60), 2)

    # Pygame rotation uses positive angles counterclockwise, so reverse the
    # screen-space direction angle to make the snout point along movement.
    angle = -direction.as_polar()[1]
    rotated_gator = pygame.transform.rotate(gator, angle)
    return pygame.transform.smoothscale(
        rotated_gator,
        (
            round(rotated_gator.get_width() * scale),
            round(rotated_gator.get_height() * scale),
        ),
    )


def get_growth_stage(current_score):
    """Return the highest growth stage whose score threshold was reached."""
    stage = growth_stages[0]
    for candidate in growth_stages[1:]:
        if current_score >= candidate[1]:
            stage = candidate
    return stage


def draw_bite_effect(surface, center, direction, reach, scale):
    """Draw two snapping jaws extending from the snout in the facing direction."""
    perpendicular = pygame.Vector2(-direction.y, direction.x)
    # Build the mouth just beyond the snout. Direction and its perpendicular
    # let the same jaw shapes point right, left, up, down, or diagonally.
    jaw_start = center + direction * (reach * 0.72)
    jaw_tip = center + direction * (reach + 34 * scale)
    jaw_length = jaw_tip - jaw_start
    jaw_thickness = 13 * scale
    jaw_gap = 5 * scale

    upper_jaw = [
        jaw_start + perpendicular * jaw_gap,
        jaw_tip + perpendicular * jaw_gap,
        jaw_tip + perpendicular * (jaw_gap + jaw_thickness),
        jaw_start + perpendicular * (jaw_gap + jaw_thickness),
    ]
    lower_jaw = [
        jaw_start - perpendicular * jaw_gap,
        jaw_tip - perpendicular * jaw_gap,
        jaw_tip - perpendicular * (jaw_gap + jaw_thickness),
        jaw_start - perpendicular * (jaw_gap + jaw_thickness),
    ]

    # A dark mouth opening between green jaws makes the snapping shape stand out.
    mouth_points = [
        jaw_start + perpendicular * jaw_gap,
        jaw_tip + perpendicular * jaw_gap,
        jaw_tip - perpendicular * jaw_gap,
        jaw_start - perpendicular * jaw_gap,
    ]
    pygame.draw.polygon(surface, (37, 35, 30), mouth_points)
    pygame.draw.polygon(surface, dark_green, upper_jaw)
    pygame.draw.polygon(surface, gator_green, upper_jaw, width=2)
    pygame.draw.polygon(surface, dark_green, lower_jaw)
    pygame.draw.polygon(surface, gator_green, lower_jaw, width=2)

    # Small pale triangles along the inner edges suggest teeth as the jaws snap.
    tooth_size = 5 * scale
    for fraction in (0.45, 0.72):
        tooth_base = jaw_start + jaw_length * fraction
        upper_tooth = [
            tooth_base + perpendicular * (jaw_gap - 1 * scale),
            tooth_base + direction * (tooth_size * 0.65)
            + perpendicular * (jaw_gap - 1 * scale),
            tooth_base + direction * tooth_size
            + perpendicular * (jaw_gap + tooth_size),
        ]
        lower_tooth = [
            tooth_base - perpendicular * (jaw_gap - 1 * scale),
            tooth_base + direction * (tooth_size * 0.65)
            - perpendicular * (jaw_gap - 1 * scale),
            tooth_base + direction * tooth_size
            - perpendicular * (jaw_gap + tooth_size),
        ]
        pygame.draw.polygon(surface, belly_green, upper_tooth)
        pygame.draw.polygon(surface, belly_green, lower_tooth)


def is_in_bite_area(target, center, direction, reach, scale):
    """Check whether a target overlaps the short forward-facing jaw zone."""
    offset = target["position"] - center
    forward_distance = offset.dot(direction)
    sideways_distance = abs(offset.dot(pygame.Vector2(-direction.y, direction.x)))
    target_radius = target["collision_radius"]

    # The projected distances describe a narrow rectangle extending from the
    # snout, padded by the person's radius so their visible edge can be bitten.
    bite_start = reach * 0.72
    bite_end = reach + 34 * scale
    bite_half_width = 18 * scale
    return (
        bite_start - target_radius <= forward_distance <= bite_end + target_radius
        and sideways_distance <= bite_half_width + target_radius
    )


def make_food_images():
    """Create small food images and retain their exact screen dimensions."""
    images = {}

    fish = pygame.Surface((42, 28), pygame.SRCALPHA)
    # Draw the original fish design around the image center.
    pygame.draw.polygon(fish, fish_outline, [(4, 14), (11, 5), (11, 23)])
    pygame.draw.ellipse(fish, fish_outline, (9, 4, 29, 21))
    pygame.draw.ellipse(fish, fish_blue, (11, 6, 25, 17))
    pygame.draw.circle(fish, food_eye_white, (32, 12), 4)
    pygame.draw.circle(fish, black, (33, 12), 2)
    pygame.draw.line(fish, fish_outline, (22, 7), (22, 21), 2)
    images["fish"] = pygame.transform.smoothscale(fish, (27, 18))

    frog = pygame.Surface((42, 42), pygame.SRCALPHA)
    # The frog's eyes and legs are included in its surface bounds.
    pygame.draw.ellipse(frog, frog_outline, (8, 13, 27, 24))
    pygame.draw.ellipse(frog, frog_orange, (10, 15, 23, 20))
    for eye_x in (16, 26):
        pygame.draw.circle(frog, frog_outline, (eye_x, 13), 6)
        pygame.draw.circle(frog, frog_orange, (eye_x, 13), 4)
        pygame.draw.circle(frog, food_eye_white, (eye_x, 12), 3)
        pygame.draw.circle(frog, black, (eye_x + 1, 12), 1)
    pygame.draw.line(frog, frog_outline, (12, 32), (5, 38), 3)
    pygame.draw.line(frog, frog_outline, (30, 32), (37, 38), 3)
    images["frog"] = pygame.transform.smoothscale(frog, (27, 27))

    turtle = pygame.Surface((48, 42), pygame.SRCALPHA)
    # A patterned rounded shell, small head, and four stubby legs identify a turtle.
    for leg_rect in ((5, 10, 12, 9), (5, 25, 12, 9), (31, 10, 12, 9), (31, 25, 12, 9)):
        pygame.draw.ellipse(turtle, dark_green, leg_rect)
        inner_rect = pygame.Rect(leg_rect).inflate(-4, -4)
        pygame.draw.ellipse(turtle, turtle_skin, inner_rect)
    pygame.draw.ellipse(turtle, dark_green, (10, 7, 28, 29))
    pygame.draw.ellipse(turtle, turtle_shell, (12, 9, 24, 25))
    pygame.draw.ellipse(turtle, turtle_shell_light, (16, 13, 16, 17), width=2)
    pygame.draw.line(turtle, turtle_shell_light, (24, 11), (24, 32), 2)
    pygame.draw.line(turtle, turtle_shell_light, (13, 21), (35, 21), 2)
    pygame.draw.ellipse(turtle, dark_green, (34, 14, 13, 14))
    pygame.draw.ellipse(turtle, turtle_skin, (36, 16, 10, 10))
    pygame.draw.circle(turtle, black, (43, 19), 1)
    images["turtle"] = turtle
    return images


def make_person_image():
    """Create a small, non-graphic person from simple clothing-colored shapes."""
    person = pygame.Surface((34, 52), pygame.SRCALPHA)
    pygame.draw.circle(person, person_skin, (17, 7), 6)
    pygame.draw.rect(person, person_shirt, (9, 14, 16, 16), border_radius=3)
    pygame.draw.rect(person, person_pants, (10, 29, 6, 16), border_radius=2)
    pygame.draw.rect(person, person_pants, (18, 29, 6, 16), border_radius=2)
    pygame.draw.line(person, person_skin, (10, 17), (4, 29), 4)
    pygame.draw.line(person, person_skin, (24, 17), (30, 29), 4)
    pygame.draw.line(person, black, (12, 45), (10, 50), 3)
    pygame.draw.line(person, black, (22, 45), (24, 50), 3)
    return person


def make_officer_image():
    """Draw a friendly, clearly uniformed wildlife officer from simple shapes."""
    officer = pygame.Surface((42, 54), pygame.SRCALPHA)
    pygame.draw.circle(officer, person_skin, (21, 9), 7)
    pygame.draw.rect(officer, officer_uniform, (9, 18, 24, 22), border_radius=4)
    pygame.draw.rect(officer, officer_uniform_light, (15, 20, 12, 18), border_radius=2)
    pygame.draw.circle(officer, officer_badge, (21, 25), 3)
    pygame.draw.rect(officer, officer_uniform, (11, 38, 8, 11), border_radius=2)
    pygame.draw.rect(officer, officer_uniform, (23, 38, 8, 11), border_radius=2)
    pygame.draw.line(officer, officer_uniform, (10, 22), (4, 35), 5)
    pygame.draw.line(officer, officer_uniform, (32, 22), (38, 35), 5)
    pygame.draw.line(officer, black, (14, 49), (12, 53), 3)
    pygame.draw.line(officer, black, (27, 49), (29, 53), 3)
    pygame.draw.rect(officer, officer_hat, (11, 1, 20, 6), border_radius=2)
    pygame.draw.rect(officer, officer_hat, (8, 6, 26, 3), border_radius=1)
    return officer


food_images = make_food_images()
person_image = make_person_image()
officer_image = make_officer_image()
food_sizes = {
    kind: (
        math.ceil(image.get_width() / 2),
        math.ceil(image.get_height() / 2),
    )
    for kind, image in food_images.items()
}
# Keep food out of the largest rotated-player boundary zone. This leaves every
# spawn within reach even after the gator reaches its Adult size.
gator_reach_margin = math.ceil(
    math.hypot(
        180 * growth_stages[-1][2] / 2,
        120 * growth_stages[-1][2] / 2,
    )
)


def spawn_food(kind=None):
    """Choose an in-bounds food location away from the player and other food."""
    if kind is None:
        kind = random.choice(("fish", "frog"))

    half_width, half_height = food_sizes[kind]
    # Include the complete food image and the player's reachable center area
    # when calculating the random center coordinates.
    minimum_x = gator_reach_margin + half_width
    maximum_x = window_width - gator_reach_margin - half_width
    minimum_y = gator_reach_margin + half_height
    maximum_y = window_height - gator_reach_margin - half_height

    # Try multiple positions to keep new food from overlapping existing objects.
    position = pygame.Vector2((minimum_x + maximum_x) / 2, (minimum_y + maximum_y) / 2)
    for _ in range(100):
        position = pygame.Vector2(
            random.randint(minimum_x, maximum_x),
            random.randint(minimum_y, maximum_y),
        )
        far_from_player = position.distance_to(player_position) > 120
        far_from_food = all(
            position.distance_to(item["position"])
            > math.hypot(*food_sizes[kind]) + math.hypot(*food_sizes[item["kind"]])
            for item in food_items
        )
        if far_from_player and far_from_food:
            break

    # Fish are small (1 point); frogs and turtles are medium (5 points).
    value = 1 if kind == "fish" else 5
    return {"kind": kind, "position": position, "value": value}


def draw_food(surface, item):
    """Draw a cached, shape-generated food image centered on its position."""
    image = food_images[item["kind"]]
    surface.blit(image, image.get_rect(center=item["position"]))


def spawn_person():
    """Place one 10-point person fully inside the adult-reachable play area."""
    half_width = math.ceil(person_image.get_width() / 2)
    half_height = math.ceil(person_image.get_height() / 2)
    minimum_x = gator_reach_margin + half_width
    maximum_x = window_width - gator_reach_margin - half_width
    minimum_y = gator_reach_margin + half_height
    maximum_y = window_height - gator_reach_margin - half_height
    position = pygame.Vector2((minimum_x + maximum_x) / 2, (minimum_y + maximum_y) / 2)

    for _ in range(100):
        position = pygame.Vector2(
            random.randint(minimum_x, maximum_x),
            random.randint(minimum_y, maximum_y),
        )
        if (
            position.distance_to(player_position) > 140
            and all(
                position.distance_to(other["position"]) > 70
                for other in person_items
            )
        ):
            break

    # The person is a large prey item; the radius follows the visible sprite.
    collision_radius = math.hypot(half_width, half_height)
    return {"position": position, "value": 10, "collision_radius": collision_radius}


def spawn_officer():
    """Spawn an officer near a screen edge and fully inside the play area."""
    margin_x = officer_image.get_width() / 2 + 4
    margin_y = officer_image.get_height() / 2 + 4
    side = random.choice(("left", "right", "top", "bottom"))
    if side == "left":
        position = pygame.Vector2(margin_x, random.randint(int(margin_y), window_height - int(margin_y)))
    elif side == "right":
        position = pygame.Vector2(window_width - margin_x, random.randint(int(margin_y), window_height - int(margin_y)))
    elif side == "top":
        position = pygame.Vector2(random.randint(int(margin_x), window_width - int(margin_x)), margin_y)
    else:
        position = pygame.Vector2(random.randint(int(margin_x), window_width - int(margin_x)), window_height - margin_y)

    # If a chosen edge is too close to the player, place the officer on the
    # opposite edge so the player has warning and space to react.
    if position.distance_to(player_position) < 180:
        position = pygame.Vector2(window_width - position.x, window_height - position.y)
    return position


# Start with several food items scattered across the play area.
for _ in range(7):
    food_items.append(spawn_food(random.choice(("fish", "frog", "turtle"))))


running = True
while running:
    # Delta time is elapsed seconds since the last frame; movement then stays
    # at the same speed even if the frame rate varies slightly.
    delta_time = clock.tick(frames_per_second) / 1000

    # Process window events so the operating system can keep the window responsive.
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif (
            event.type == pygame.KEYDOWN
            and (game_over or game_won)
            and event.key == pygame.K_r
        ):
            # Restart all gameplay state, including prey, growth, officer, and timers.
            score = 0
            health = maximum_health
            player_position = pygame.Vector2(window_width / 2, window_height / 2)
            facing_direction = pygame.Vector2(1, 0)
            food_items.clear()
            person_items.clear()
            officer_position = None
            officer_respawn_at = 0
            invulnerable_until = 0
            bite_visible_until = 0
            bite_cooldown_until = 0
            game_over = False
            game_won = False
            for _ in range(7):
                food_items.append(
                    spawn_food(random.choice(("fish", "frog", "turtle")))
                )
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_k:
            # Trigger once per key press; the cooldown prevents rapid repeated bites.
            current_time = pygame.time.get_ticks()
            if not (game_over or game_won) and current_time >= bite_cooldown_until:
                bite_visible_until = current_time + bite_duration_ms
                bite_cooldown_until = current_time + bite_cooldown_ms

    if game_over or game_won:
        # Freeze gameplay in either end state while leaving restart and close responsive.
        screen.fill(swamp_green)
        if game_won:
            end_message = "YOU WIN!"
            end_detail = f"You reached {win_score} points!"
        else:
            end_message = "GAME OVER"
            end_detail = f"Final score: {score}"
        end_text = pygame.font.Font(None, 72).render(end_message, True, white)
        detail_text = font.render(end_detail, True, white)
        restart_text = font.render("Press R to restart", True, white)
        screen.blit(
            end_text,
            end_text.get_rect(center=(window_width / 2, window_height / 2 - 48)),
        )
        screen.blit(
            detail_text,
            detail_text.get_rect(center=(window_width / 2, window_height / 2 + 4)),
        )
        screen.blit(
            restart_text,
            restart_text.get_rect(center=(window_width / 2, window_height / 2 + 44)),
        )
        pygame.display.flip()
        continue

    # Combine held keys into a direction. Normalizing prevents diagonal movement
    # from being faster than moving horizontally or vertically.
    keys = pygame.key.get_pressed()
    movement = pygame.Vector2(
        int(keys[pygame.K_d]) - int(keys[pygame.K_a]),
        int(keys[pygame.K_s]) - int(keys[pygame.K_w]),
    )
    if movement.length_squared() > 0:
        facing_direction = movement.normalize()
        movement = movement.normalize()
        player_position += movement * player_speed * delta_time

    # Choose the highest stage earned so far; thresholds and scales are defined
    # together above so stage progression is easy to adjust while testing.
    growth_stage, _, gator_scale = get_growth_stage(score)

    # People are introduced only at Adult stage and one replacement is kept
    # available after each successful bite.
    if growth_stage == "Adult" and not person_items:
        person_items.append(spawn_person())

    current_time = pygame.time.get_ticks()
    # Wildlife officers enter at Juvenile and remain a threat at Adult.
    if growth_stage != "Baby" and officer_position is None and current_time >= officer_respawn_at:
        officer_position = spawn_officer()

    # Rotate toward the last movement direction, and use the rotated image size
    # to keep the entire alligator inside the window at every angle.
    gator_image = make_baby_gator(facing_direction, gator_scale)
    player_position.x = max(
        gator_image.get_width() / 2,
        min(window_width - gator_image.get_width() / 2, player_position.x),
    )
    player_position.y = max(
        gator_image.get_height() / 2,
        min(window_height - gator_image.get_height() / 2, player_position.y),
    )

    # Scale the circular player hit area along with the visible alligator.
    player_collision_radius = 40 * gator_scale / baby_gator_scale

    # The officer slowly follows the player but stays inside the window.
    if officer_position is not None:
        pursuit = player_position - officer_position
        if pursuit.length_squared() > 0:
            officer_position += pursuit.normalize() * officer_speed * delta_time
        officer_position.x = max(
            officer_image.get_width() / 2,
            min(window_width - officer_image.get_width() / 2, officer_position.x),
        )
        officer_position.y = max(
            officer_image.get_height() / 2,
            min(window_height - officer_image.get_height() / 2, officer_position.y),
        )

    # Compare object centers using circular hit areas. When food is collected,
    # award its points and replace it with a newly spawned item.
    for item in food_items[:]:
        food_collision_radius = math.hypot(*food_sizes[item["kind"]])
        if (
            player_position.distance_to(item["position"])
            <= player_collision_radius + food_collision_radius
        ):
            score += item["value"]
            food_items.remove(item)
            if score >= win_score:
                # Reaching the target immediately freezes the game as a victory.
                game_won = True
                break
            food_items.append(spawn_food(item["kind"]))

    # Touching does not collect a person: an active K bite must also overlap
    # the forward jaw area before the person is removed and respawned.
    if (
        not game_won
        and growth_stage == "Adult"
        and pygame.time.get_ticks() < bite_visible_until
    ):
        bite_scale = gator_scale / baby_gator_scale
        for person in person_items[:]:
            if is_in_bite_area(
                person,
                player_position,
                facing_direction,
                player_collision_radius,
                bite_scale,
            ):
                score += person["value"]
                person_items.remove(person)
                if score >= win_score:
                    # Large prey can also complete the objective on a bite.
                    game_won = True
                    break
                person_items.append(spawn_person())

    # A successful active bite repels the officer without awarding food points.
    if (
        not game_won
        and officer_position is not None
        and current_time < bite_visible_until
        and growth_stage != "Baby"
    ):
        officer_target = {
            "position": officer_position,
            "collision_radius": officer_collision_radius,
        }
        if is_in_bite_area(
            officer_target,
            player_position,
            facing_direction,
            player_collision_radius,
            gator_scale / baby_gator_scale,
        ):
            officer_position = None
            officer_respawn_at = current_time + officer_respawn_delay_ms

    # Contact removes one life only when temporary protection has expired.
    # The officer is sent away after a hit, creating time to recover.
    if (
        not game_won
        and officer_position is not None
        and current_time >= invulnerable_until
        and player_position.distance_to(officer_position)
        <= player_collision_radius + officer_collision_radius
    ):
        health -= 1
        invulnerable_until = current_time + invulnerability_duration_ms
        officer_position = None
        officer_respawn_at = current_time + officer_respawn_delay_ms
        if health <= 0:
            game_over = True

    if game_won or game_over:
        # Winning or losing ends normal updates immediately.
        continue

    # Draw the swamp and player, then show the finished frame in the window.
    screen.fill(swamp_green)
    for item in food_items:
        draw_food(screen, item)
    for person in person_items:
        screen.blit(person_image, person_image.get_rect(center=person["position"]))
    if officer_position is not None:
        screen.blit(officer_image, officer_image.get_rect(center=officer_position))

    gator_rect = gator_image.get_rect(center=player_position)
    # Blink during temporary protection so invulnerability is obvious.
    if current_time >= invulnerable_until or current_time // 120 % 2 == 0:
        screen.blit(gator_image, gator_rect)

    # Show a brief shape effect in front of the snout while a bite is active.
    if pygame.time.get_ticks() < bite_visible_until:
        bite_reach = player_collision_radius
        draw_bite_effect(
            screen,
            player_position,
            facing_direction,
            bite_reach,
            gator_scale / baby_gator_scale,
        )

    # Show the score goal and explain R is available after either end state.
    control_text = font.render("WASD = Move | K = Bite", True, white)
    screen.blit(control_text, (16, 16))
    score_text = font.render(f"Score: {score}", True, white)
    score_rect = score_text.get_rect(topright=(window_width - 16, 16))
    screen.blit(score_text, score_rect)
    stage_text = font.render(f"Stage: {growth_stage}", True, white)
    screen.blit(stage_text, (16, 48))
    health_text = font.render(f"Health: {health}/{maximum_health}", True, white)
    screen.blit(health_text, (16, 80))
    goal_text = font.render(f"Goal: Reach {win_score} points", True, white)
    screen.blit(goal_text, (16, 112))
    restart_hint = font.render("R = Restart after win or Game Over", True, white)
    screen.blit(restart_hint, (16, 144))
    officer_text = font.render("Avoid or bite the wildlife officer!", True, white)
    if growth_stage != "Baby":
        screen.blit(officer_text, (16, 176))
    pygame.display.flip()

# Shut down Pygame cleanly after the window is closed.
pygame.quit()
